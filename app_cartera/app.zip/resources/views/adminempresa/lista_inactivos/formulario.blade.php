

<div class="form-group">
    {!! Form::label('cartera_id', 'Cartera a la cual se va asignar', ['for' => 'exampleFormControlInput1']) !!}
    {{ Form::select('cartera_id', $empresa_carteras, null, ['class'=>'form-control']) }}
</div>

















