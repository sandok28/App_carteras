<div class="form-group">
    {!! Form::label('nombre', 'Nombre', ['for' => 'exampleFormControlInput1']) !!}
    {!! Form::text('nombre', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']) !!}
</div>

<div class="form-group">
    {!! Form::label('precio', 'Precio', ['for' => 'exampleFormControlInput1']) !!}
    {!! Form::number('precio', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']) !!}
</div>

<div class="form-group">
    {!! Form::label('descripcion', 'Descripcion', ['for' => 'exampleFormControlInput1']) !!}
    {!! Form::text('descripcion', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']) !!}
</div>











