<div class="form-group">
    {!! Form::label('nombre', 'Nombre', ['for' => 'exampleFormControlInput1']) !!}
    {!! Form::text('nombre', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']) !!}
</div>

<div class="form-group">
    {!! Form::label('cedula', 'Cedula', ['for' => 'exampleFormControlInput1']) !!}
    {!! Form::number('cedula', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']) !!}
</div>

<div class="form-group">
    {!! Form::label('telefono', 'Telefono', ['for' => 'exampleFormControlInput1']) !!}
    {!! Form::number('telefono', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']) !!}
</div>

<div class="form-group">
    {!! Form::label('direccion', 'Direccion', ['for' => 'exampleFormControlInput1']) !!}
    {!! Form::text('direccion', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']) !!}
</div>

<div class="form-group">
    {!! Form::label('correo', 'Correo electronico', ['for' => 'exampleFormControlInput1']) !!}
    {!! Form::text('email', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']) !!}
</div>

<div class="form-group">
    {!! Form::label('contraseña', 'Password', ['for' => 'exampleFormControlInput1']) !!}
    {!! Form::text('contrasena', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']) !!}
</div>












