
@extends('layouts.app')

@section('titulo_pigina')
    Carterista
@endsection

@section('content_css')
       
@endsection

@section('content')
    <main>
         <!-- Main page content-->
         <div class="container mt-4">
            <!-- Account page navigation-->
            <hr class="mt-0 mb-4" />
            <div class="row">
                
                <div class="col-xl-12">
                    <!-- Account details card-->
                    <div class="card card-header-actions">
                        <div class="card-header">
                            Resumen del dia
                            <button class="btn btn-primary btn-sm">Volver</button>
                        </div>
                        <div class="card-body">
                            <p>Credito cartera anterior: {{$creditoinicial}}</p>
                            <p>Ventas del dia: {{$venta}}</p>
                            <p>Abonos del dia: {{$abono}}</p>
                            <p>saldo cartera: {{$saldo}}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
@endsection

@section('content_js')

@endsection
