



<?php $__env->startSection('titulo_pigina'); ?>
    Carterista
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <main>
        <!-- Main page content-->
        <div class="container mt-4">
            <!-- Account page navigation-->
            <hr class="mt-0 mb-4" />
            <div class="row">
                
                <div class="col-xl-12">
                    <!-- Account details card-->
                    <div class="card mb-4">
                    
                        <div class="card-header">Abono a deuda</div>
                        <div class="card-body">
                            <?php echo $__env->make('Partials.formularios.alerta_validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <?php echo Form::model($cliente, ['route' => ['carterista.cliente.recaudo',$cliente], 'method' => 'POST']); ?>

                                <div class="form-group">
                                    <label class="small mb-1" for="inputUsername">Cliente:  <?php echo e($cliente->nombre); ?></label>  
                                    </br>  
                                    <label class="small mb-1" for="inputUsername">Cedula:  <?php echo e($cliente->cedula); ?></label>                              
                                    </br>                            
                                    <label class="small mb-1" for="inputUsername">Direccion:  <?php echo e($cliente->direccion); ?></label>                                
                                    </br>
                                    <label class="small mb-1" for="inputUsername">Telefono:  <?php echo e($cliente->telefonoo); ?></label>                                
                                    </br>
                                    <label class="small mb-1" for="inputUsername">Deuda:  <?php echo e($cliente->deuda); ?></label>                                
                                </div>
                            
                                <div class="form-group">
                                    <?php echo Form::label('Pago','Pago: ', ['for' => 'exampleFormControlInput1']); ?>    
                                    <?php echo Form::number('pago', null, ['min' => '0', 'max' => $cliente->deuda,'class' => 'form-control', 'id' => 'exampleFormControlInput1', 'placeholder'=>'Deuda actual: '.$cliente->deuda ]); ?>

                                </div>                               
                                    
                                <div class="form-group"> 
                                <?php echo Form::submit('Aceptar', ['class' => 'btn btn-success col-md-10'] ); ?>

                                </div>
                                <div class="form-group"> 
                                    <a class="btn btn-primary col-md-10" type="button" href="<?php echo e(route('carterista.gestion_cliente_cartera', $cliente->id)); ?>">Cancelar</a>
                                </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
 
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/carteristas/clientes/formulario_pagar.blade.php ENDPATH**/ ?>