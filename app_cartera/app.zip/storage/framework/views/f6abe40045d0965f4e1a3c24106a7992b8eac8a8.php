

<?php $__env->startSection('titulo_pigina'); ?>
    Crear cartera
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <!-- Main page content-->
        <div class="container mt-4">
            <!-- Account page navigation-->
            <hr class="mt-0 mb-4" />
            <div class="row">
                
                <div class="col-xl-12">
                    <!-- Account details card-->
                    <div class="card mb-4"> 
                        <div class="card-header">Registrar cliente </div>
                        <div class="card-body">
                            <?php echo $__env->make('Partials.formularios.alerta_validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <?php echo Form::open(['route' => 'carterista.clientes.clientes_crear', 'method' => 'POST']); ?>

                         
                                <?php echo $__env->make('carteristas.clientes.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <div class="form-group"> 
                                    <?php echo Form::submit('Guardar', ['class' => 'btn btn-success  col-md-10'] ); ?>

                                </div>
                                <div class="form-group"> 
                                    <a class="btn btn-primary  col-md-10" type="button" href="<?php echo e(route('carterista')); ?>">Volver</a>
                                </div>
                                
                                
                                
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/carteristas/clientes/formulario_clientes_crear.blade.php ENDPATH**/ ?>