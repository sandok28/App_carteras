<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre de la empresa', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('descripcion', 'Descripcion', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::text('descripcion', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1', 'rows' => '3']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('telefono', 'Telefono', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::number('telefono', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

</div>
 
<?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/administradores/administrador_empresas/formulario.blade.php ENDPATH**/ ?>