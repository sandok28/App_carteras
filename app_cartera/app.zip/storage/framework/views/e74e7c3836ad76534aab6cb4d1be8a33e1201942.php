




<?php $__env->startSection('titulo_pigina'); ?>
    Lista de clientes lista negra
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_css'); ?>
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
            <div class="container">
                <div class="page-header-content pt-12">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">Panel de administracion de clientes de la empresa</div>
                                <div class="row center-md card-body">
                                    <div class="col-md-8"></div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main page content-->
        <div class="container mt-n10">
            <div class="card mb-4">  
                <div class="card-header">Listado de clientes pendientes en lista negra</div>
                <div class="card-body">
                    <div class="datatable">
                        <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Direccion</th>
                                    <th>Telefono</th>
                                    <th>Cedula</th>
                                    <th>Deuda</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Direccion</th>
                                    <th>Telefono</th>
                                    <th>Cedula</th>
                                    <th>Deuda</th>
                                    <th>Acciones</th>
                                </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $clientesP; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cliente->nombre); ?></td>
                                    <td><?php echo e($cliente->direccion); ?></td>
                                    <td><?php echo e($cliente->telefono); ?></td>
                                    <td><?php echo e($cliente->cedula); ?></td>
                                    <td><?php echo e($cliente->deuda); ?></td>
                                    <td>
                                        <a class="btn btn-datatable btn-icon btn-transparent-dark mr-2" href="<?php echo e(url('/empresa/listanegra/'.$cliente->id.'/formulario_cliente_listanegra_actualizar')); ?>"title="Cambiar Cliente de Cartera"><i data-feather="edit"></i></a>
                                        <a class="btn btn-datatable btn-icon btn-transparent-dark mr-2" href="<?php echo e(url('/empresa/listanegra/confirmar/'.$cliente->id)); ?>"title="Enviar Cliente a Lista Negra"><i data-feather="x-circle"></i></a>
                                     </td>
                                </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 

            <div class="card mb-4">  
                <div class="card-header">Listado de clientes confirmados en lista negra</div>
                <div class="card-body">
                    <div class="datatable">
                        <table class="table table-bordered table-hover" id="dataTable2" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Direccion</th>
                                    <th>Telefono</th>
                                    <th>Cedula</th>
                                    <th>Deuda</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Direccion</th>
                                    <th>Telefono</th>
                                    <th>Cedula</th>
                                    <th>Deuda</th>
                                    <th>Acciones</th>
                                </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $clientesC; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cliente->nombre); ?></td>
                                    <td><?php echo e($cliente->direccion); ?></td>
                                    <td><?php echo e($cliente->telefono); ?></td>
                                    <td><?php echo e($cliente->cedula); ?></td>
                                    <td><?php echo e($cliente->deuda); ?></td>
                                    <td>
                                        <a class="btn btn-datatable btn-icon btn-transparent-dark mr-2" href="<?php echo e(url('/empresa/listanegra/'.$cliente->id.'/formulario_cliente_listanegra_actualizar')); ?>" title="Trasladar"><i data-feather="edit"></i></a>
                                    </td>
                                </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </main>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_js'); ?>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
   
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/adminempresa/empresa_LN.blade.php ENDPATH**/ ?>