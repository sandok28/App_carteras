<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-icon" role="alert">
        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
        <div class="alert-icon-aside">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        <div class="alert-icon-content">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <h6><?php echo e($error); ?></h6>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>

<?php if(Session::get('tipo') == 'error'): ?>
    <div class="alert alert-danger alert-icon" role="alert">
        <button class="close" type="button" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
        <div class="alert-icon-aside">
            <i class="far fa-flag"></i>
        </div>
        <div class="alert-icon-content">
        <?php echo e(Session::get('message')); ?>

        </div>
    </div>
<?php endif; ?>

<?php if(Session::get('tipo') == 'message'): ?>
    <div class="alert alert-success alert-dismissible" role="alert" style="margin-bottom: 1em;">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo e(Session::get('message')); ?>

    </div>
    <br>
<?php endif; ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/Partials/formularios/alerta_validaciones.blade.php ENDPATH**/ ?>