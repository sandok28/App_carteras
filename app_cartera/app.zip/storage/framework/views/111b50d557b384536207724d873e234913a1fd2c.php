<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('descripcion', 'Descripcion', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::textarea('descripcion', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1', 'rows' => '3']); ?>

</div>

<?php echo e(Form::hidden('empresa_id', $empresa_id)); ?>






<?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/administradores/administrador_carteras/formulario.blade.php ENDPATH**/ ?>