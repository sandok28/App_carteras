




<?php $__env->startSection('titulo_pigina'); ?>
    Carterista
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_css'); ?>
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
            <div class="container">
                <div class="page-header-content pt-12">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-auto mt-4">
                            <h1 class="page-header-title">
                                <div class="page-header-icon"><i data-feather="chevrons-right"></i></div>
                                <?php echo e(is_null($cartera) ? 'Sin cartera' : $cartera->nombre); ?>

                            </h1>
                            <div class="page-header-subtitle">
                                <?php echo e(is_null($cartera) ? 'No cuenta con carteras asignadas para hoy.' : $cartera->descripcion); ?>

                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main page content-->
        <div class="container mt-n10"><!-- Styled timeline component example -->
            <div class="timeline">
                <?php if(!is_null($clientes_por_atender)): ?>
                    <?php $__currentLoopData = $clientes_por_atender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                    
                        <div class="timeline-item">                        
                            <div class="timeline-item-content pt-0">
                                <div class="card shadow-sm">
                                    <div class="card-body">
                                        <h5 class="text-primary"><a href = "<?php echo e(route('carterista.gestion_cliente_cartera',$cliente->id)); ?>"><?php echo e($cliente->posicion); ?> - <?php echo e($cliente->nombre); ?> </a><span class="badge badge-warning">Pendiente</span></h5>
                                        <?php echo e($cliente->direccion); ?>

                                        </br>
                                        Deuda: $<?php echo e($cliente->deuda); ?>

                                    </div>
                                </div>
                            </div>
                        </div>                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if(!is_null($clientes_atendidos)): ?>
                    <?php $__currentLoopData = $clientes_atendidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="timeline-item">                        
                            <div class="timeline-item-content pt-0">
                                <div class="card shadow-sm">
                                    <div class="card-body">
                                        <h5 class="text-primary"><a href = "<?php echo e(route('carterista.gestion_cliente_cartera',$cliente->id)); ?>"><?php echo e($cliente->nombre); ?> </a> <span class="badge badge-success">Atendido</span></h5>
                                        <?php echo e($cliente->direccion); ?>

                                        </br>
                                        Deuda: $<?php echo e($cliente->deuda); ?>

                                    </div>
                                </div>
                            </div>
                        </div>                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_js'); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/carteristas/panel_central_carteristas.blade.php ENDPATH**/ ?>