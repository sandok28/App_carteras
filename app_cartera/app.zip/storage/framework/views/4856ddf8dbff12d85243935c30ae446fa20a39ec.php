




<?php $__env->startSection('titulo_pigina'); ?>
    Bodega
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_css'); ?>
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
            <div class="container">
                <div class="page-header-content pt-12">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-md-12">
                            <div class="card">
                            <div class="card-header">Carteras de la empresa</div>
                                <div class="row center-md card-body">
                                    <div class="col-md-8"></div>
                                    
                                    
                                
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main page content-->
        <div class="container mt-n10"><!-- Styled timeline component example -->
            <div class="timeline">
                <?php $__currentLoopData = $carteras_por_atender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="timeline-item">
                        <div class="timeline-item-marker">
                        <div class="timeline-item-marker-text"></div>
                            <div class="timeline-item-marker-indicator bg-warning-soft text-primary"><i data-feather="x"></i></div>
                        </div>
                        <div class="timeline-item-content pt-0">
                            <div class="card shadow-sm">
                                <div class="card-body">
                                    <h5 class="text-primary"><?php echo e($cartera->nombre); ?></h5>
                                    Direccion:<?php echo e($cartera->descripcion); ?>

                                </div>
                                <a class="btn btn-primary col-md-2" type="button" href="<?php echo e(route('bodega.formulario_cargar_cartera',$cartera->id)); ?>">Cargar</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $carteras_atendidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="timeline-item">
                        <div class="timeline-item-marker">
                        <div class="timeline-item-marker-text"></div>
                            <div class="timeline-item-marker-indicator bg-success-soft text-primary"><i data-feather="check"></i></div>
                        </div>
                        <div class="timeline-item-content pt-0">
                            <div class="card shadow-sm">
                                <div class="card-body">
                                    <h5 class="text-primary"><?php echo e($cartera->nombre); ?></h5>
                                    Direccion:<?php echo e($cartera->descripcion); ?>

                                </div>
                                <a class="btn btn-primary col-md-2" type="button" href="<?php echo e(route('bodega.informacion_carga_cartera',$cartera->id)); ?>">Cargar</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/bodega/panel_central_bodega.blade.php ENDPATH**/ ?>