<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Plantilla boostrap -->
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

    <title><?php echo $__env->yieldContent('titulo_pigina'); ?></title>
            
    <script data-search-pseudo-elements defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.27.0/feather.min.js" crossorigin="anonymous"></script>

    <?php echo $__env->yieldContent('content_css'); ?>

</head>
<body class="nav-fixed">
        <?php if(auth()->guard()->guest()): ?>
            <?php echo $__env->yieldContent('content'); ?>
        <?php else: ?>
        <nav class="topnav navbar navbar-expand shadow navbar-light bg-white" id="sidenavAccordion">
            <a class="navbar-brand" href="/">Cabasistem</a>
            <button class="btn btn-icon btn-transparent-dark order-1 order-lg-0 mr-lg-2" id="sidebarToggle" href="#"><i data-feather="menu"></i></button>
            
            <ul class="navbar-nav align-items-center ml-auto">
                        
                
                <li class="nav-item dropdown no-caret mr-2 dropdown-user">
                    
                    <a class="btn btn-icon btn-transparent-dark dropdown-toggle" id="navbarDropdownUserImage" href="javascript:void(0);" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img class="img-fluid" src="<?php echo e(asset('img/icono.png')); ?>" /></a>
                    <div class="dropdown-menu dropdown-menu-right border-0 shadow animated--fade-in-up" aria-labelledby="navbarDropdownUserImage">
                        <h6 class="dropdown-header d-flex align-items-center">
                            <img class="dropdown-user-img" src="<?php echo e(asset('img/icono.png')); ?>" />
                            <div class="dropdown-user-details">
                                <div class="dropdown-user-details-name"> <?php echo e(Auth::user()->name); ?></div>
                                <div class="dropdown-user-details-email"><?php echo e(Auth::user()->email); ?></div>
                            </div>
                        </h6>
                        <div class="dropdown-divider"></div>
                        
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <div class="dropdown-item-icon"><i data-feather="log-out"></i></div>
                            Cerrar sesion
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                    </div>
                </li>
            </ul>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sidenav shadow-right sidenav-light">
                    
                    
                    <?php if( Auth::user()->usuarios->get(0)->tipo == "1" ): ?>
                        <?php echo $__env->make('Partials.general.panel_lateral_administrador', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php elseif( Auth::user()->usuarios->get(0)->tipo == "2" ): ?>

                        <?php echo $__env->make('Partials.general.panel_lateral_empresa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php elseif( Auth::user()->usuarios->get(0)->tipo == "4" ): ?>

                        <?php echo $__env->make('Partials.general.panel_lateral_bodega', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php elseif( Auth::user()->usuarios->get(0)->tipo == "3" ): ?>

                        <?php echo $__env->make('Partials.general.panel_lateral_carterista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php endif; ?>

                    <div class="sidenav-footer">
                        <div class="sidenav-footer-content">
                            <div class="sidenav-footer-subtitle">Usuario en sesion</div>
                            <div class="sidenav-footer-title"><?php echo e(Auth::user()->name); ?></div>
                        </div>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                    <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

        <?php endif; ?>
            
       
         <!-- Scripts -->
        <!--<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>  pude er util mas adelante si nada falla borrar-->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
       <script src="<?php echo e(asset('js/scripts.js')); ?>" defer></script>
        <?php echo $__env->yieldContent('content_js'); ?>
</body>
</html>
<?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/layouts/app.blade.php ENDPATH**/ ?>