


<?php $__env->startSection('titulo_pigina'); ?>
    Carterista
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_css'); ?>
       
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
         <!-- Main page content-->
         <div class="container mt-4">
            <!-- Account page navigation-->
            <hr class="mt-0 mb-4" />
            <div class="row">
                
                <div class="col-xl-12">
                    <!-- Account details card-->
                    <div class="card card-header-actions">
                        <div class="card-header">
                            Resumen del dia
                            <button class="btn btn-primary btn-sm">Volver</button>
                        </div>
                        <div class="card-body">
                            <p>Credito cartera anterior: <?php echo e($creditoinicial); ?></p>
                            <p>Ventas del dia: <?php echo e($venta); ?></p>
                            <p>Abonos del dia: <?php echo e($abono); ?></p>
                            <p>saldo cartera: <?php echo e($saldo); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/carteristas/resumen_del_dia.blade.php ENDPATH**/ ?>