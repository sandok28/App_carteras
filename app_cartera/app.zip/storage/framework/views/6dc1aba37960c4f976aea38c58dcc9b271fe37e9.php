



<?php $__env->startSection('titulo_pigina'); ?>
    Editar producto
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

    <main>
        <!-- Main page content-->
        <div class="container mt-4">
            <!-- Account page navigation-->
            <hr class="mt-0 mb-4" />
            <div class="row">
                
                <div class="col-xl-12">
                    <!-- Account details card-->
                    <div class="card mb-4">
                        <div class="card-header">Editar producto</div>
                        <div class="card-body">
                            <?php echo $__env->make('Partials.formularios.alerta_validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                            <?php echo Form::model($producto, ['route' => ['empresa.empresa_productos.empresa.productos_actualizar', $producto], 'method' => 'PUT']); ?>

                                
                                <?php echo $__env->make('adminempresa.productos.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                                <?php echo Form::submit('Actualizar', ['class' => 'btn btn-success'] ); ?>

                                <a class="btn btn-primary " type="button" href="<?php echo e(route('empresa.empresa_productos')); ?>">Volver</a>
                            
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
 
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/adminempresa/productos/formulario_productos_actualizar.blade.php ENDPATH**/ ?>