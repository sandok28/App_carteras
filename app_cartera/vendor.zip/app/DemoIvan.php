<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DemoIvan extends Model
{
    //
}
