

<div class="form-group">
    <?php echo Form::label('cartera_id', 'Cartera a la cual se va asignar', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo e(Form::select('cartera_id', $empresa_carteras, null, ['class'=>'form-control'])); ?>

</div>

















<?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/adminempresa/listanegra/formulario.blade.php ENDPATH**/ ?>