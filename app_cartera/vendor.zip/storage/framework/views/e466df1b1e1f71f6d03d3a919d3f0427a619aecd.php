<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('email', 'Carterista', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo e(Form::select('usuario_id', $usuarios_empresa, null, ['class'=>'form-control'])); ?>

     
</div>

<?php echo e(Form::hidden('empresa_id', $empresa_id)); ?>






<?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/adminempresa/carteras/formulario.blade.php ENDPATH**/ ?>