



<?php $__env->startSection('titulo_pigina'); ?>
    Crear usuario
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

       <div id="layoutSidenav_content">
            <main>
                <!-- Main page content-->
                <div class="container mt-4">
                    <!-- Account page navigation-->
                    <hr class="mt-0 mb-4" />
                    <div class="row">
                        
                        <div class="col-xl-12">
                            <!-- Account details card-->
                            <div class="card mb-4">
                            <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <p><?php echo e($error); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                                <div class="card-header">Registrar usuario</div>
                                <div class="card-body">
                                    <form method="POST" action="/usuarios" enctype="mutipart/form-data">
                                    <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Nombre</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="nombre" type="text">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Cedula</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="cedula" type="text">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Nit</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="nit" type="text">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Telefono</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="telefono" type="text">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Direccion</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="direccion" type="text">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Tipo de usuario</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="tipo" type="text">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Empresa_id</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="empresa_id" type="text">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Correo</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="email" type="text">
                                        </div>
                                        
                                        <button type="submit" class="btn btn-success">
                                                Guardar
                                        </button>
                                        <a class="btn btn-primary " type="button" href="<?php echo e(url()->previous()); ?>">Volver</a>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/usuarios/create.blade.php ENDPATH**/ ?>