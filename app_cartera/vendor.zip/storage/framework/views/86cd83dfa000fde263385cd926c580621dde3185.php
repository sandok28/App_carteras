



<?php $__env->startSection('titulo_pigina'); ?>
    Lista carteras
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_css'); ?>
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
            <div class="container">
                <div class="page-header-content pt-12">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">Panel de administracion de carteras</div>
                                <div class="row center-md card-body">
                                
                                    <div class="col-md-8"></div>
                                    <a class="btn btn-primary col-md-2" type="button" href="<?php echo e(url()->previous()); ?>">Volver</a>
                                
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main page content-->
        <div class="container mt-n10">
            <div class="card mb-4">
                <div class="card-header">Listado de carteras</div>
                <div class="card-body">
                    <div class="datatable">
                        <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Carterista</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Carterista</th>                                   
                                    <th>Acciones</th>
                                </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $empresa_carteras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($cartera->nombre); ?></td>
                                    <td><?php echo e($cartera->usuario->nombre); ?></td>
                                    <td>


                                        <a class="btn btn-datatable btn-icon btn-transparent-dark mr-2" href="<?php echo e(url('/empresa/carteras/'.$cartera->id.'/formulario_cartera_actualizar')); ?>"><i data-feather="edit"></i></a>
                                        <a class="btn btn-datatable btn-icon btn-transparent-dark mr-2" href="<?php echo e(url('/empresa/carteras/'.$cartera->id.'/clientes')); ?>" title="clientes de la cartera"><i data-feather ="users"></i></a>
                                        <a class="btn btn-datatable btn-icon btn-transparent-dark mr-2" href="<?php echo e(url('/empresa/bonos/'.$cartera->id)); ?>" title="bonos de la cartera"><i data-feather ="dollar-sign"></i></a>
                                        <a class="btn btn-datatable btn-icon btn-transparent-dark mr-2" href="<?php echo e(url('/empresa/novedades/'.$cartera->id)); ?>" title="novedades de la cartera"><i data-feather ="eye"></i></a>
                                                                                                           
                                        

                                        
                                    </td>
                                </tr>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>        
        </div>
    </main>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_js'); ?>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
   
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>" defer></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/adminempresa/empresa_carteras.blade.php ENDPATH**/ ?>