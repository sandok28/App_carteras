



<?php $__env->startSection('titulo_pigina'); ?>
    Bodega
<?php $__env->stopSection(); ?>

                                                            

<?php $__env->startSection('content'); ?>

    <main>
        <!-- Main page content-->
        <div class="container mt-4">
            <!-- Account page navigation-->
            <hr class="mt-0 mb-4" />
            <div class="row">
                
                <div class="col-xl-12">
                    <!-- Account details card-->
                    <div class="card mb-4">
                    
                        <div class="card-header">Descargar productos a la cartera</div>
                        <div class="card-body">
                            <?php echo $__env->make('partials.formularios.alerta_validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                            <?php echo Form::model($producto_nevera, ['route' => ['bodega.descargar_cartera',$nevera_id], 'method' => 'POST']); ?>

                                

                                <?php $__currentLoopData = $producto_nevera; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nevera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="form-group">
                                    <?php echo Form::label('nombre',$nevera->producto->nombre.' --> Cantidad en nevera ('.$nevera->cantidad.')'.' --> Cantidad en bodega ('.$nevera->producto->cantidad.')', ['for' => 'exampleFormControlInput1']); ?>

                                    <?php echo Form::selectRange('cantidad',0,$nevera->producto->cantidad, null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

                                        
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                                <?php echo Form::submit('Actualizar', ['class' => 'btn btn-success'] ); ?>

                                <a class="btn btn-primary " type="button" href="<?php echo e(url()->previous()); ?>">Volver</a>
                            
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/bodega/cargar/formulario_cartera_descargar.blade.php ENDPATH**/ ?>