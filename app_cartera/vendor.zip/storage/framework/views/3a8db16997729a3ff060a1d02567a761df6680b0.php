

<?php $__env->startSection('title'.'trainers create'); ?>

<?php $__env->startSection('content'); ?>

<form class="form-group" methos="POST" action="/trainers">
<?php echo csrf_field(); ?>
    <div class="form-group">
    <label for="">nombre</label>
    <input type="text" name="name" class="form-control">
    </div>
    <button type="submit" class="btn btn-primary">guardar</button>
   </form>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/trainers/create.blade.php ENDPATH**/ ?>