<div class="form-group">
    <?php echo Form::label('nombre', '<?php echo e($producto->nombre); ?>', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

</div>











<?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/bodega/cargar/formulario.blade.php ENDPATH**/ ?>