<div class="form-group">
    <?php echo Form::label('nombre', 'Nombre', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::text('nombre', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('cedula', 'Cedula', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::text('cedula', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('telefono', 'Telefono', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::text('telefono', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('direccion', 'Direccion', ['for' => 'exampleFormControlInput1']); ?>

    <?php echo Form::text('direccion', null, ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

</div>













<?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/adminempresa/carteristas/formulario.blade.php ENDPATH**/ ?>