



<?php $__env->startSection('titulo_pigina'); ?>
    Actualizar lista negra
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

       <div id="layoutSidenav_content">
            <main>
                <!-- Main page content-->
                <div class="container mt-4">
                    <!-- Account page navigation-->
                    <hr class="mt-0 mb-4" />
                    <div class="row">
                        
                        <div class="col-xl-12">
                            <!-- Account details card-->
                            <div class="card mb-4">
                                <div class="card-header">Actualizar lista negra</div>
                                <div class="card-body">
                                    <form method="POST" action="/listanegras/<?php echo e($listanegras->id); ?>" enctype="mutipart/form-data">
                                    <?php echo method_field('PUT'); ?>
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                            <label for="exampleFormControlInput1">Cliente_id</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="clientes_id" type="text" value="<?php echo e($listanegras->cliente_id); ?>">
                                        </div>
                                       

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Monto_ingreso</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="monto_ingreso" type="text" value="<?php echo e($listanegras->monto_ingreso); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleFormControlInput1">Estado</label>
                                            <input class="form-control" id="exampleFormControlInput1" name="estado" type="text" value="<?php echo e($listanegras->estado); ?>">
                                        </div>
                                        
                                       

                                        
                                        <button type="submit" class="btn btn-success">
                                                Actualizar
                                        </button>
                                        <a class="btn btn-primary " type="button" href="<?php echo e(url()->previous()); ?>">Volver</a>
                                        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/ivan/listanegras/editar.blade.php ENDPATH**/ ?>