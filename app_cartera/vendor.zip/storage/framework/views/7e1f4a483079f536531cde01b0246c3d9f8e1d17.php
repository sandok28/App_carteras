

<?php $__env->startSection('titulo_pigina'); ?>
    Crear cartera
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <!-- Main page content-->
        <div class="container mt-4">
            <!-- Account page navigation-->
            <hr class="mt-0 mb-4" />
            <div class="row">
                
                <div class="col-xl-12">
                    <!-- Account details card-->
                    <div class="card mb-4"> 
                        <div class="card-header">Registrar bodeguistas </div>
                        <div class="card-body">
                            <?php echo $__env->make('partials.formularios.alerta_validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <?php echo Form::model($usuario, ['route' => ['empresa.bodeguistas.correo_bodeguistas_actualizar', $usuario], 'method' => 'PUT']); ?>

      
                                <div class="form-group">
                                <?php echo Form::label('email', 'Email', ['for' => 'exampleFormControlInput1']); ?>

                                <?php echo Form::text('email', ( empty($usuario) ? '' : $usuario->correo_user()), ['class' => 'form-control', 'id' => 'exampleFormControlInput1']); ?>

                                </div>

                                <?php echo Form::submit('Guardar', ['class' => 'btn btn-success'] ); ?>

                                <a class="btn btn-primary " type="button" href="<?php echo e(url()->previous()); ?>">Volver</a>
                                
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Users\STIVE\Documents\App_carteras\app_cartera\resources\views/adminempresa/bodeguistas/formulario_correo_editar.blade.php ENDPATH**/ ?>